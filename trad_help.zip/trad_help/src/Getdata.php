<?php

namespace StockAnalyzer;
class Getdata {
    private $rawData = [];
    private $headers = [];
    public function __construct($filePath, $withHeader = false, $parseAsOrm = false)
    {
        $file = fopen($filePath,"r");
        if ($withHeader) {
            $this->headers = fgetcsv($file);
        }
        while(!feof($file))
        {
            $row = fgetcsv($file);
            
            if (!$row) {
                continue;
            }
            if ($withHeader && $parseAsOrm) {
                $orm = [];
                foreach ($this->headers as $key => $header) {
                    $orm[$header] = $row[$key];
                }
                array_push($this->rawData, $orm);
            } else {
                array_push($this->rawData, $row);
            }
        }
        fclose($file);
    }
    public function getRaw() {
        return $this->rawData;
    }
    public function getHead() {
        return $this->headers;
    }
}