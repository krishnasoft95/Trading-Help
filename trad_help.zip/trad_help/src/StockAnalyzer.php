<?php
namespace StockAnalyzer;
use StockAnalyzer\FormValidator;
use StockAnalyzer\Getdata;
use StockAnalyzer\SiteHelper;
class StockAnalyzer {
    private static $csvDateFormat = "d-m-Y";
    public static function Calculate() {
        $validator = FormValidator::validate();

        if (!$validator["check"]) {
            return [
                "success" => false,
                "errors" => $validator["messages"]
            ];
        }
        $csvValues = new Getdata($_FILES["csv_file"]["tmp_name"], true, true);
        if ([
                "id_no",
                "date",
                "stock_name",
                "price"
            ] !== $csvValues->getHead()
        ) {
            return [
                "success" => false,
                "errors" => ["Invalid Headers in CSV"]
            ];
        }
        $csvData = $csvValues->getRaw();
        $invalidCsv = false;
        foreach ($csvData as $key => $data) {
            $csvData[$key]["stock_name"] = strtoupper(trim($data["stock_name"]));
            $dates = date_create_from_format(self::$csvDateFormat, trim($data["date"]));
            if (!$dates) {
                $invalidCsv = true;
                return [
                    "success" => false,
                    "errors" => ["Invalid Values in CSV"]
                ];
                break;
            }
            $csvData[$key]["dates"] = $dates;
            $price = trim($data["price"]);
            if (!preg_match ("/^[0-9]*$/", $price) || intval($price) < 0) {
                $invalidCsv = true;
                return [
                    "success" => false,
                    "errors" => ["Invalid Values in CSV"]
                ];
                break;
            }
            $csvData[$key]["price"] = intval($price);
        }
        if ($invalidCsv) {
            return;
        }
        $filteredData = [];
        $stock_name = strtoupper(trim($_POST["stock_name"]));
        $FromDate = date_create(trim($_POST["from_date"]));
        $ToDate = date_create(trim($_POST["to_date"]));
        foreach ($csvData as $data) {
            if ($data['stock_name'] !== $stock_name) {
                continue;
            }
            if ($data["dates"] < $FromDate) {
                continue;
            }
            if ($data["dates"] > $ToDate) {
                continue;
            }
            array_push($filteredData, $data);
        }
        if (count($filteredData) < 2) {
            return [
                "success" => false,
                "errors" => ["No data available for given CSV Files."]
            ];
            return;
        }
        $DataSort = [];
        $totaldays = intval(date_diff($FromDate, $ToDate)->format('%a'));
        for ($i = 0; $i <= $totaldays; $i++) {
            $DataSort[$i] = null;
        }
        foreach($filteredData as $data) {
            $dayIndex = intval(date_diff($FromDate, $data["dates"])->format("%a"));
            $DataSort[$dayIndex] = $data;
        }
        $DataSort = array_values(array_filter($DataSort));
        $TotalPrices = [];
        foreach ($DataSort as $data) {
            array_push($TotalPrices, $data["price"]);
        }
        $ProfitPrice = SiteHelper::ProfitCalculation($TotalPrices);
        $MPrice = SiteHelper::MeanCalculation($TotalPrices);
        $Deviation = SiteHelper::DeviationCalculation($TotalPrices);
        $buyPrice = $ProfitPrice[0];
        $buyDate = null;
        $sellPrice = $ProfitPrice[1];
        $sellDate = null;
        foreach ($DataSort as $data) {
            if (!$buyDate && $buyPrice === $data["price"]) {
                $buyDate = $data["date"];
            }
            if ($buyDate && $sellPrice === $data["price"]) {
                $sellDate = $data["date"];
                break;
            }
        }
        return [
            "success" => true,
            "data" => [
                 "stock_name" => $stock_name,
                "buydate" => $buyDate,
                "selldate" => $sellDate,
                "profit" => ($sellPrice - $buyPrice),
                "mean" => $MPrice,
                "Deviation" => $Deviation
            ]
        ];
    }
}
