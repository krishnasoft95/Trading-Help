<?php

namespace StockAnalyzer;
class SiteHelper {
    public static function ProfitCalculation($prices) {
    
        $CountData = count($prices);

        if ($CountData < 2) {
            return [];
        }
        $Profit  = 0;
        $Buy = $prices[0];
        $allSell = $prices[1];
        $allProfit = $allSell - $Buy;
        for ($i = 1; $i < $CountData; $i++) {
            $Profit = $prices[$i] - $Buy;
            if ($Profit > $allProfit) {
                $allProfit = $Profit;
                $allSell = $prices[$i];
            }
            if ($prices[$i] < $Buy) {
                $Buy = $prices[$i];
            }
        }
    
        return [$allSell - $allProfit, $allSell];
    }
    public static function MeanCalculation($prices): float {
        return round(
            array_sum($prices) / count($prices), 2
        );
    }
    public static function DeviationCalculation($prices): float {

        $PricesCount = count($prices);

        if ($PricesCount < 2) {
            return 0;
        }

        $MPrice  = self::MeanCalculation($prices);

        $DeviationArray = [];

        foreach ($prices as $price) {
            array_push($DeviationArray, pow($price - $MPrice, 2));
        }

        $Deviation = array_sum($DeviationArray) / ($PricesCount - 1);

        return round(sqrt($Deviation), 2);
    }
}