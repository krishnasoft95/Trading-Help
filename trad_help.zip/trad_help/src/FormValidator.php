<?php
namespace StockAnalyzer;
class FormValidator {
    public static function validate(): array {
        $check = true;
        $messages = [];
        $allvaidation = [
            self::StockNameCheck(),
            self::FromDateCheck(),
            self::ToDateCheck(),
        ];
        foreach ($allvaidation as $valid) {
            if (!$valid["check"]) {
                $check = false;
                array_push($messages, $valid["message"]);
            }
        }
        return [
            "check" => $check,
            "messages" => $messages
        ];
    }
    private static function StockNameCheck(): array {
        if (!isset($_POST["stock_name"])) {
            return [
                "check" => false,
                "message" => "Stock name is required"
            ];
        }
        if (!trim($_POST["stock_name"])) {
            return [
                "check" => false,
                "message" => "Stock name shoud not be empty"
            ];
        }
        if (!preg_match ("/^[a-zA-z0-9]*$/", trim($_POST["stock_name"]))) {
            return [
                "check" => false,
                "message" => "Stock name is must be valid string"
            ];
        }
        return ["check" => true];
    }
    private static function FromDateCheck(): array {
        if (!isset($_POST["from_date"])) {
            return [
                "check" => false,
                "message" => "From date is required"
            ];
        }
        if (!trim($_POST["from_date"])) {
            return [
                "check" => false,
                "message" => "From date shoud not be empty"
            ];
        }
        if (!date_create($_POST["from_date"])) {
            return [
                "check" => false,
                "message" => "From date is invalid"
            ];
        }

        return ["check" => true];
    }
    private static function ToDateCheck(): array {
        if (!isset($_POST["to_date"])) {
            return [
                "check" => false,
                "message" => "To date is required"
            ];
        }
        if (!trim($_POST["to_date"])) {
            return [
                "check" => false,
                "message" => "To date shoud not be empty"
            ];
        }
        
        $enddate = date_create($_POST["to_date"]);
        if (!$enddate) {
            return [
                "check" => false,
                "message" => "To date is invalid"
            ];
        }

        $startdate = null;

        if (isset($_POST["from_date"])) {
            $startdate = date_create($_POST["from_date"]);
        }

        if ($startdate && $enddate) {
            if ($enddate <= $startdate) {
                return [
                    "check" => false,
                    "message" => "To date must be greater than From date"
                ];
            }
        }

        return ["check" => true];
    }
}