<!DOCTYPE html>
<html lang="en">
 <?php include './header.php';  ?>
   <body>
  <main id="main">
    <section class="breadcrumbs">
      <div class="container">
        <div class="d-flex justify-content-between align-items-center">
          <h2>Welcome</h2>
        </div>
      </div>
    </section>
    <section class="inner-page">
      <div class="container">
          <div class="row">
              <div class="col-md-6">
        
                  <form id="form"  method="post">
                   <div class="row">
              <div class="col-md-6">
                <div class="form-group">
                    <label class="form-label">Upload CSV File</label>
                    <input type="file" name="csv_file" id="csv_file" class="form-control" accept=".csv" required="">
                </div>
              </div>
               <div class="col-md-6">
                <div class="form-group" id="stldis" style="display:none;">
                    <label class="form-label">Select Stock Name</label>
                    <select class="form-control" name="stock_name" id="stock_name" required="">
                    </select>
                </div>
                 </div></div><br>
                   <div class="row">
              <div class="col-md-6">
                <div class="form-group" id="stfdat" style="display:none;">
                    <label class="form-label">From Date</label>
                    <input type="date" name="from_date" class="form-control" required="">
                </div>
                  </div>
               <div class="col-md-6">
                <div class="form-group" id="sttdat" style="display:none;">
                    <label class="form-label">To Date</label>
                    <input type="date" name="to_date" class="form-control" required="">
                </div>
                    </div></div><br>
                <button type="submit" class="btn btn-primary">Submit</button>
            </form>
              </div>
              <div class="col-md-6">
                  <div id="error_toast" class="alert alert-secondary" style="display: none;">
            </div>
             <div id="output" class="alert alert-info" style="display: none;">
            </div>
            </div>
              </div>
          </div>
      </div>
    </section>
  </main>
   <?php  include './footer.php'; ?>
      
 </body>
</html>