function selectbox(csv, delimiter = ",") {
                const headers = csv.slice(0, csv.indexOf("\n")).split(delimiter);
                const rows = csv.slice(csv.indexOf("\n") + 1).split("\n");
                const arrays = rows.map(function (row) {
                    const values = row.split(delimiter);
                    const element = headers.reduce(function (object, header, index) {
                    object[header] = values[index];
                    return object;
                    }, {});
                    return element;
                });
                return arrays;
            };
 function StockSelect(data) {
                const stockname = new Set();
                for (var val of data) {
                    if (val.stock_name) {
                        const stock = val.stock_name.trim();
                        if (stock) {
                            stockname.add(stock.toUpperCase());
                        }
                    }
                }
                 
               if(stockname !=''){
                   show_element(); 
               }else{
                  hide_element();
               }
               
                var select = "<option selected disabled>Select Stock Name</option>";
                for (var stock_val of stockname) {
                    select += "<option value='" + stock_val + "'>" + stock_val + "</option>";
                }
                document.getElementById("stock_name").innerHTML = select;
            }
            function show_element(){
              const sts = document.getElementById("stldis");
               sts.style.display = "block";
               const stfdate = document.getElementById("stfdat");
               stfdate.style.display = "block";
                const sttdate = document.getElementById("sttdat");
               sttdate.style.display = "block";
            }
             function hide_element(){
               const sts = document.getElementById("stldis");
               sts.style.display = "none";
                const stfdate = document.getElementById("stfdat");
               stfdate.style.display = "none";
               const sttdate = document.getElementById("sttdat");
    sttdate.style.display = "none";
            }
 window.onload = function () {
                document.getElementById("csv_file").onchange = function (csv) {
                    if (csv.target.files.length) {
                        const inputFile = csv.target.files[0];
                        const reader = new FileReader();
                        reader.onload = function (csv) {
                            const text = csv.target.result;
                            const data = selectbox(text);
                           StockSelect(data);
                        };
                        reader.readAsText(inputFile);
                    }
                }
                 document.getElementById("form").onsubmit = function (e) {
                    e.preventDefault();
                    report();
                }
            }
             function report() {
                     fetch("results.php", {
                    method: 'POST',
                    body: new FormData(document.getElementById("form")),
                    headers: {
                        'Accept': 'application/json'
                    },
                }).then(response => response.json())
                .then(data => {
                    const error_toast = document.getElementById("error_toast");
                    const output = document.getElementById("output");
                    if (data.success) {
                        error_toast.style.display = "none";
                        let resultHtml = "<table border=1 width=100%><tr><th>Stock Name</th><th>Buy Date</th><th>Sell Date</th><th>Profit</th><th>Mean</th><th>Deviation</th></tr><tr>";
                        resultHtml += "<td>" + data.data.stock_name + "</td>";
                        resultHtml += "<td>" + data.data.buydate + "</td>";
                        resultHtml += "<td>" + data.data.selldate + "</td>";
                        resultHtml += "<td>" + data.data.profit + "</td>";
                        resultHtml += "<td>" + data.data.mean + "</td>";
                        resultHtml += "<td>" + data.data.Deviation + "</td>";
                        resultHtml += "</tr></table>";
                        output.innerHTML = resultHtml;
                        output.style.display = "block";
                    } else {
                        output.style.display = "none";
                        let errorHtml = "";
                        for (let error of data.errors) {
                            errorHtml += "<table border=1 width=100%><tr><th>Error Toast</th></tr><tr><td>" + error + "</td></tr></table>";
                        }
                
                 error_toast.innerHTML = errorHtml;
                        error_toast.style.display = "block";
                    }
                })
                .catch((error) => {
                    console.error('Error:', error);
                });
            }