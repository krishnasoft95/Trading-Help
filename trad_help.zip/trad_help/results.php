<?php
include("vendor/load.php");

use StockAnalyzer\StockAnalyzer;
echo json_encode(StockAnalyzer::Calculate());
return;