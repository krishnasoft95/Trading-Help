<footer id="footer" style="margin-top: 320px;">
    <div class="container d-md-flex">
      <div class="me-md-auto text-center text-md-start">
        <div class="copyright">
            &copy; <?php echo date('Y');?> <a href="javascript:void(0)">KrishnaSoft</a>. All Rights Reserved.
        </div>
      </div>
    </div>
  </footer>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="assets/js/main.js"></script>
  <script src="assets/js/global.js"></script>
  <script src="assets/js/custom.js"></script>
 